/*
  -------------------------------------------------------------------
   Copyright (C) 2007 :
   - ANTRAIGUE Lionel
   - NEUHAUSER Cl�ment
   - POIGNANT Matthieu
   - ROCHEGUDE Romain

   Soci�t� Octolys
   http://thelia.fr
  -------------------------------------------------------------------
*/

//---------------    THELIA R�ference - BOUCLES / BALISES    ---------------

var tab_param_entree = new Array ;
var tab_param_sortie = new Array ;

// tab_param_entree 

tab_param_entree ['ACCESSOIRE']= new Array('id') ;
tab_param_entree ['ADRESSE']= new Array ( 'adresse' , 'client' ) ;
tab_param_entree ['CARACDISP']= new Array ( 'caracteristique' , 'id' , 'etcaracteristique' , 'etcaracdisp' , 'classement' ) ;
tab_param_entree ['CARACTERISTIQUE']= new Array ('id', 'rubrique' , 'produit','affiche') ;
tab_param_entree ['CARACVAL']= new Array ( 'caracteristique' , 'produit' , 'valeur' ) ;
tab_param_entree ['CHEMIN']= new Array ('rubrique', 'profondeur' , 'niveau') ;
tab_param_entree ['CLIENT']= new Array (  'id' , 'ref' , 'raison' , 'nom','cpostal','ville','pays','parrain','revendeur' ) ;
tab_param_entree ['COMMANDE']= new Array ( 'ref' , 'client', 'statut' ) ;
tab_param_entree ['CONTENU']= new Array ('dossier' , 'deb' , 'num' , 'bloc' , 'id' , 'motcle' , 'produit' , 'rubrique' , 'motcle' , 'classement' , 'profondeur' , 'courant' , 'aleatoire') ;
tab_param_entree ['DECLIDISP']= new Array ( 'id' , 'declinaison' , 'produit');
tab_param_entree ['DECLINAISON']= new Array ('id' , 'rubrique' , 'produit') ;
tab_param_entree ['DECVAL']= new Array ('article') ;
tab_param_entree ['DEVISE']= new Array('produit' , 'id' , 'somme') ;
tab_param_entree ['DOCUMENT']= new Array ('produit', 'rubrique' , 'dossier', 'contenu', 'num', 'nb', 'debut');
tab_param_entree ['DOSSIER']= new Array('id' , 'parent' , 'boutique' , 'courant' , 'ligne') ;
tab_param_entree ['IMAGE']= new Array('produit','id', 'num', 'nb', 'debut', 'rubrique', 'largeur', 'hauteur', 'dossier', 'contenu', 'opacite', 'noiretblanc', 'miroir', 'aleatoire') ;
tab_param_entree ['PAGE']= new Array ('num', 'courante' , 'pagecourante','typeaff', 'max' , 'affmin' ) ;
tab_param_entree ['PAIEMENT']= new Array ('id') ;
tab_param_entree ['PANIER']= new Array ('deb', 'fin' , 'dernier') ;
tab_param_entree ['PAYS']= new Array ('id', 'zone' , 'zdefinie','select', 'default' ) ;
tab_param_entree ['PRODUIT']= new Array('rubrique', 'boutique', 'deb', 'num', 'bloc', 'nouveaute', 'promo', 'reappro', 'ref', 'id', 'garantie', 'motcle', 'classement', 'aleatoire', 'prixmin', 'prixmax', 'caracteristique', 'caracdisp', 'caracval', 'courant', 'profondeur');
tab_param_entree ['QUANTITE']= new Array ('article') ;
tab_param_entree ['RSS']= new Array( 'url' , 'deb' , 'nb') ;
tab_param_entree ['RUBRIQUE']= new Array('id' , 'parent' , 'boutique' , 'courante' , 'pasvide' , 'ligne' , 'aleatoire') ;
tab_param_entree ['STOCK']= new Array ( 'declidisp' , 'produit') ;
tab_param_entree ['TRANSPORT']= new Array ( 'id' ) ;
tab_param_entree ['VENTPROD']= new Array ( 'commande' ) ;


// tab_param_sortie - Logiquement � deduire de CLASSEMENT et NON-CLASSEMENT

tab_param_sortie ['CARACDISP']= new Array ('ID' , 'TITRE' , 'CARACTERISTIQUE' ) ;
tab_param_sortie ['CARACVAL']= new Array ('ID'  , 'CARACDISP', 'VALEUR', 'RUBRIQUE', 'TITRECARAC') ;
tab_param_sortie ['ADRESSE']= new Array ('ID','LIBELLE','RAISON','NOM','PRENOM','ADRESSE1','ADRESSE2','ADRESSE3','CPOSTAL','VILLE','PAYS','EMAIL','TELFIXE','TELPORT','SUPPRURL','URL') ;
tab_param_sortie ['COMMANDE']= new Array ('ID','ADRESSE','DATE','REF','LIVRAISON','FACTURE','DATELIVRAISON','ENVOI','PAIEMENT','REMISE','STATUT','TOTALCMD','PORT','TOTCMDPORT','FICHIER') ;
tab_param_sortie ['VENTPROD']= new Array ('ID','REF','TITRE','CHAPO','DESCRIPTION','QUANTITE','PRIXU','TOTALPROD') ;
tab_param_sortie ['CLIENT']= new Array ('ID','REF','RAISON','NOM','PRENOM','TELFIXE','TELPORT','EMAIL','ADRESSE1','ADRESSE2','ADRESSE3','CPOSTAL','VILLE','PAYS','PARRAIN','TYPE','POURCENTAGE') ;
tab_param_sortie ['TRANSPORT']= new Array ('ID','TITRE','CHAPO','DESCRIPTION','PORT','URLCMD') ;
tab_param_sortie ['RSS']= new Array ('SALON' , 'WEB' , 'TITRE' , 'LIEN' , 'DESCRIPTION' , 'AUTEUR' , 'DATE' , 'HEURE') ;
tab_param_sortie ['CONTENU']= new Array ('DATE' , 'HEURE' , 'DEBCOURANT' , 'ID' , 'DOSSIER' , 'TITRE' , 'STRIPTITRE' , 'CHAPO' , 'STRIPCHAPO' , 'DESCRIPTION' , 'STRIPDESCRIPTION' , 'URL' , 'REWRITEURL' ,  'URLBOUTIQUE' ,  'RUBTITRE') ;
tab_param_sortie ['DECLINAISON']= new Array ('ID' , 'TITRE' , 'CHAPO' , 'DESCRIPTION' , 'PRODUIT') ;
tab_param_sortie ['DECLIDISP']= new Array ( 'ID' , 'DECLINAISON' , 'TITRE' , 'PRODUIT' ) ;
tab_param_sortie ['STOCK']= new Array ( 'ID' , 'DECLIDISP' , 'PRODUIT' , 'VALEUR') ;
tab_param_sortie ['DECVAL']= new Array ("DECLITITRE" , "VALEUR") ;
tab_param_sortie ['RUBRIQUE']= new Array ('TITRE' , 'STRIPTITRE' , 'CHAPO' , 'STRIPCHAPO' , 'DESCRIPTION' , 'PARENT' , 'ID' , 'URL' , 'REWRITEURL' , 'LIEN' , 'COMPT' , 'NBRES' , 'NBENFANT') ;
tab_param_sortie ['DOSSIER']= new Array ('TITRE' , 'STRIPTITRE' , 'CHAPO' , 'STRIPCHAPO' , 'DESCRIPTION' , 'PARENT' , 'ID' , 'URL' , 'REWRITEURL' , 'LIEN' , 'COMPT' , 'NBRES' , 'NBENFANT') ;
tab_param_sortie ['IMAGE']= new Array ('PRODUIT' , 'RUBRIQUE' , 'PRODTITRE' , 'PRODREF' , 'GRANDE' , 'PETITE' , 'FPETITE' , 'FGRANDE' , 'RUBTITRE' , 'ID' , 'COMPT') ;
tab_param_sortie ['DEVISE']= new Array ('PRIX' , 'PRIX2', 'TOTAL', 'CONVERT', 'NOM', 'CODE', 'TAUX') ;
tab_param_sortie ['ACCESSOIRE']= new Array ('ACCESSOIRE') ;
tab_param_sortie ['DOCUMENT']= new Array ('TITRE' , 'FICHIER' ) ;
tab_param_sortie ['PRODUIT']= new Array ('REF', 'DATE', 'HEURE', 'DEBCOURANT', 'ID', 'PRIX' , 'PRIX2', 'POURCENTAGE', 'RUBRIQUE', 'PERSO', 'QUANTITE', 'POIDS', 'TITRE', 'STRIPTITRE', 'CHAPO', 'STRIPCHAPO', 'DESCRIPTION', 'STRIPDESCRIPTION', 'URLBOUTIQUE', 'URL', 'REWRITEURL', 'GARANTIE', 'PANIER', 'RUBTITRE') ;
tab_param_sortie ['PAGE']= new Array ("PAGE_NUM" , "PAGE_SUIV",  "PAGE_PREC" , "RUBRIQUE" ) ;
tab_param_sortie ['PANIER']= new Array ("REF" , "ID",  "TITRE" , "QUANTITE" ,"PRODUIT" , "PRIXU","TOTAL" , "REMISE","PLUSURL" , "MOINSURL",  "SUPPRURL" , "PRODURL" ,"TOTSANSPORT" , "PORT",  "TOTPORT" , "DECTEXTE", "DECVAL") ;
tab_param_sortie ['QUANTITE']= new Array ("NUM" , "SELECTED") ;
tab_param_sortie ['CHEMIN']= new Array ("ID" , "TITRE",  "URL" ) ;
tab_param_sortie ['PAIEMENT']= new Array ("ID" , "URLTYPE",  "URLPAYER" , "LOGO" , "TITRE",  "CHAPO" , "DESCRIPTION" ) ;
tab_param_sortie ['PAYS']= new Array ("ID" , "TITRE", "CHAPO" , "DESCRIPTION", "SELECTED" ,"DEFAULT" ) ;
tab_param_sortie ['CARACTERISTIQUE']= new Array ("ID" , "TITRE", "CHAPO" , "DESCRIPTION" ) ;

/*
  -------------------------------------------------------------------
   THELIA_reference.js
  -------------------------------------------------------------------
*/