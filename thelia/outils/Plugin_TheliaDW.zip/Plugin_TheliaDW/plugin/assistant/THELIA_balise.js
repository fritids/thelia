/*
  -------------------------------------------------------------------
   Copyright (C) 2007 :
   - ANTRAIGUE Lionel
   - NEUHAUSER Cl�ment
   - POIGNANT Matthieu
   - ROCHEGUDE Romain

   Soci�t� Octolys
   http://thelia.fr
  -------------------------------------------------------------------
*/

//---------------     Var MSG    ---------------

var msg_abs_nom = "Le NOM de la BOUCLE doit toujours �tre renseign� ! " ;
	msg_abs_nom += "\n\n Par d�faut, le nom \'Votre_Boucle\' va �tre utilis�." ;
	

//---------------     API FUNCTIONS    ---------------

function isDOMRequired() {
	// Return false, indicating that this object is available in code view.
	return false;
}


function objectTag()
{
	var str_Boucle_Start = '';
	var str_Boucle_End = '';
	var str_content = '';
	var str_Param = '';
	var str_br = '' ;
	
	var f = document.forms[0] ;
	
	var affichage_balise = f.affichage_balise.options[f.affichage_balise.selectedIndex].value;
	var balise_name = f.name.value ;
  	var balise_type = f.balisetype.value;
	
	// -- Utilisation des balises <br> dans le code
	if( f.br_add.checked )
		str_br = '<br />' ;

		
	// -- Msg d'alerte - Abscence de nom pour la balise
	if (balise_name == '')
	{
		alert( msg_abs_nom );		
  		balise_name = "Votre_Boucle" ;
  	}	
	
	// -- Ajout de '_' si 'balise_name' est de type texte
 	var reg_balise_name = /([^0-9])/; 

	if ( reg_balise_name.exec(balise_name))
	{
		// Suppresion des espaces
		balise_name = balise_name.replace( /([\s\W])/gi , '_') ;
		balise_name = "_" + balise_name ;		
  	}		

	// -- Parametre
	function tab_critere(tab, critere_base )
	{
		var critere = '' ;
		var str = '' ;
		for ( var k=0 ; k < tab[balise_type].length ; k++ )
		{	
			critere = critere_base + tab[balise_type][k] ;						
			if ( eval("f."+critere+".checked") )
				str  += ' ' + tab[balise_type][k] + '=" " ';
		} 
		return str ;
	}
				
	str_Param  += tab_critere(tab_param_entree, 'select__' ) ;
	str_Param = str_Param.replace( /___/gi , ' = ') ;
	str_Param = str_Param.replace( /_N_/gi , ' != ') ;
	
	// gestion des crit�re type 'par hasard'
	str_Param = str_Param.replace( /__/gi , ' ') ;	
	
	// -- Balise � afficher
	var balise = '' ;
	var balise_content = '';
	
	if( affichage_balise != "rien" )
	{	
		for ( var i=0 ; i < tab_param_sortie[balise_type].length ; i++ )
		{	
			balise = tab_param_sortie [balise_type][i] ;
			balise_content = ' #' + balise ;

			if ( affichage_balise != "tout" )
			{
				if ( eval("f."+balise+".checked") )
					str_content += str_br + balise_content + str_br + '\n' ;
			}
			else
				str_content += str_br + balise_content + str_br + '\n' ;
		}  
	}


	// -- Balise <BOUCLE>
	str_Boucle_Start += '<THELIA'  + balise_name +' type="'+ balise_type +'"';
	str_Boucle_Start += str_Param ;
	str_Boucle_Start += '>\n'  ;

	str_Boucle_End += '\n</THELIA' + balise_name +'>\n';


	// -- G�n�ration...	
	var beginWrap = str_Boucle_Start ;
		beginWrap += str_content ;
			
	var endWrap = str_Boucle_End ;

	var dom = dw.getDocumentDOM();
	dom.source.wrapSelection(beginWrap,endWrap);
	// Just return -- don't do anything else.
	return;

}

/*
  -------------------------------------------------------------------
   THELIA_balise.js
  -------------------------------------------------------------------
*/